
# Urinary Tract Infection - Early Symptoms

Burning urination, frequency, fever...
